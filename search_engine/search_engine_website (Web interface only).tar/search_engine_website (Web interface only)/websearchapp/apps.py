from django.apps import AppConfig


class WebsearchappConfig(AppConfig):
    name = 'websearchapp'
