#!C:/Users/Anjana/Anaconda3/python.exe

import search_engine as se
Max_Count = 50
def search(string):
	url_list = se.web_search_main(string)
	return url_list[:Max_Count]